package Laboratorio.ar.org.centro8.entities.entities;

public abstract class Vehiculo {

public // ATRIBUTO
private String marca;
private String modelo;
private String color;
private Radio radio;
private Double precio;

// UN VEHICULO SIEMPRE TIENE RADIO
// UNA RADIO SIEMPRE PERTENECE A UN VEHICULO

public Vehiculo(String marca, String modelo, String color, String marcaRadio, String potencia, Double precio) {
    this.marca = marca;
    this.modelo = modelo;
    this.color = color;
    this.radio = new Radio(marcaRadio, potencia);
    this.precio = precio;
}

// UN VEHICULO PUEDE CREARSE SIN RADIO Y CON PRECIO
public Vehiculo(String marca, String modelo, String color, Double precio) {
    this.marca = marca;
    this.modelo = modelo;
    this.color = color;
    this.precio = precio;

}

// VEHICULO CON RADIO Y SIN PRECIO

public Vehiculo(String marca, String modelo, String color, String marcaRadio, String potencia) {
    this.marca = marca;
    this.modelo = modelo;
    this.color = color;
    this.radio = new Radio(marcaRadio, potencia);
}

// VEHICULO SIN RADIO Y SIN PRECIO
public Vehiculo(String marca, String modelo, String color) {
    this.marca = marca;
    this.modelo = modelo;
    this.color = color;
}

public void agregarRadio(String marcaRadio, String potencia) {
    if ((marcaRadio != null) || (potencia != null)) {
        System.out.println("Ya tiene radio");
    } else {
        this.radio = new Radio(marcaRadio, potencia);
    }

}

public void modificarRadio(String marcaRadio, String potencia) {
    if (radio != null) {
        this.radio = new Radio(marcaRadio, potencia);
    } else {
        System.out.println("No tiene radio");
    }

}

@Override
public String toString() {
    return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", radio=" + radio + ", precio="
            + precio + "]";
}

public String getMarca() {
    return marca;
}

public String getModelo() {
    return modelo;
}

public String getColor() {
    return color;
}

public Radio getRadio() {
    return radio;
}

public Double getPrecio() {
    return precio;
}

public void setPrecio(Double precio) {
    this.precio = precio;
}
}