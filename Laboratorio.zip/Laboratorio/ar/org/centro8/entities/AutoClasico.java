package ar.org.centro8.entities;

public class AutoClasico extends Vehiculo {

    //SE PUEDE CREAR CON RADIO Y PRECIO

    public AutoClasico(String marca, String modelo, String color, String marcaRadio, String potencia, Double precio) {
        super(marca, modelo, color, marcaRadio, potencia, precio);
    }

    
    //SE PUEDE CREAR SIN RADIO Y CON PRECIO

    public AutoClasico(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio);
    }
 
    //SE PUEDE CREAR CON RADIO Y SIN PRECIO
    public AutoClasico(String marca, String modelo, String color, String marcaRadio, String potencia) {
        super(marca, modelo, color, marcaRadio, potencia);
    }

    //SE PUEDE CREAR SIN RADIO Y SIN PRECIO
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }


    @Override
    public String toString() {
        return "AutoClasico ["+ super.toString() +"]";
    }
    
 
}