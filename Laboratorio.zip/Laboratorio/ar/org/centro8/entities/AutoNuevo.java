package Laboratorio.ar.org.centro8.entities;

public class AutoNuevo extends Vehiculo {

    //PUEDE CREARSE CON RADIO
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, String potencia, Double precio) {
        super(marca, modelo, color, marcaRadio, potencia, precio);
    }
    
    //SIEMPRE TIENE RADIO NO TIENE PRECIO

    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, String potencia) {
        super(marca, modelo, color, marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "AutoNuevo ["+ super.toString() +"]";
    }

}