package Laboratorio.ar.org.centro8.entities;
public final class Colectivo extends Vehiculo{

 
    // PUEDE CREARSE CON RADIO Y CON PRECIO
    public Colectivo(String marca, String modelo, String color, String marcaRadio, String potencia, Double precio) {
        super(marca, modelo, color, marcaRadio, potencia, precio);
    }

    // PUEDE CREARSE SIN RADIO Y CON PRECIO

    public Colectivo(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio);
    }

    // PUEDE CREARSE CON RADIO Y SIN PRECIO 
    public Colectivo(String marca, String modelo, String color, String marcaRadio, String potencia) {
        super(marca, modelo, color, marcaRadio, potencia);
    }

    //PUEDE CREARSE SIN RADIO Y SIN PRECIO
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    @Override
    public String toString() {
        return  "Colectivo ["+ super.toString() +"]";
    }

   
}