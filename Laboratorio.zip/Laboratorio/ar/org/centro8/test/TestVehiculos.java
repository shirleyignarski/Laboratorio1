package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;


public class TestVehiculos {
    
    public static void main(String[] args) {

        System.out.println("---AutoClasico---");

        //PUEDE CREARSE SIN RADIO Y SIN PRECIO

        AutoClasico autoclasico2 = new AutoClasico("", "", "");
        
        //PUEDE CREARSE CON RADIO Y CON PRECIO

        AutoClasico autoclasico3 = new AutoClasico(null, null, null, null, null, null);
       
        //PUEDE CREARSE CON RADIO Y SIN PRECIO

        AutoClasico autoclasico4 = new AutoClasico(null, null, null, null, null);

        //PUEDE CREARSE SIN RADIO Y CON PRECIO

        AutoClasico autoclasico1 = new AutoClasico("", "", "", null);        
        System.out.println(autoclasico1);

        autoclasico1.modificarRadio("", "");
        System.out.println(autoclasico1);

        autoclasico1.agregarRadio("", "");
        System.out.println(autoclasico1);

        System.out.println("-----AutoNuevo-------");
        //PUEDE CREARSE SIN RADIO Y CON PRECIO
        AutoNuevo autonuevo2 = new AutoNuevo(null, null, null, null, null);

        //PUEDE CREARSE CON RADIO Y CON PRECIO
        AutoNuevo autonuevo1 = new AutoNuevo("", "", "", "", "", );
        System.out.println(autonuevo1);

        autonuevo1.agregarRadio("", "");
        System.out.println(autonuevo1);

        autonuevo1.modificarRadio("", "");
        System.out.println(autonuevo1);

        System.out.println("---------Colectivo----------");
        //PUEDE CREARSE CON RADIO Y SIN PRECIO

        Colectivo colectivo2 = new Colectivo(null, null, null, null, null);

        //PUEDE CREARSE SIN RADIO Y SIN PRECIO

        Colectivo colectivo3 = new Colectivo(null, null, null);

        //PUEDE CREARSE SIN RADIO Y CON PRECIO

        Colectivo colectivo4 = new Colectivo(null, null, null, null);
        
        //PUEDE CREARSE CON RADIO Y CON PRECIO
        Colectivo colectivo1 = new Colectivo("", "", "", "", "", null);
        System.out.println(colectivo1);

        colectivo1.agregarRadio("", "");
        System.out.println(colectivo1);

        colectivo1.modificarRadio("", "");
        System.out.println(colectivo1);

        colectivo1.setPrecio(1000000.);
        System.out.println(colectivo1);
  
    }
}